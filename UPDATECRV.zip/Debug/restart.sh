#!/bin/sh

sudo kill $(ps aux | grep ControlRoomViewer.exe | awk '{print $2}')
sudo chown pi.pi /code/ControlRoomViewer.exe
sudo chmod +x /code/ControlRoomViewer.exe
/home/pi/Desktop/loadcontrolroom.sh
