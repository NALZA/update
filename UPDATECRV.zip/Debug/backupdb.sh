#!/bin/sh
HOST1=$1
DATE=$(date +"%Y%m%d%H%M")
FILE2=$DATE.sql

mysqldump -u root -pJ3nk1n$ -h $HOST1 sillabels > /code/backup/$FILE2

